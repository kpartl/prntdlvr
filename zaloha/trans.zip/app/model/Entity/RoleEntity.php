<?php
namespace Model\Entity;
use LeanMapper;

/**
 * @property int $id (ID)
 * @property string $name (NAME)
 */
class Role extends AEntity
{
}
