<?php
namespace Model\Repository;

use Model;

/**
 * Class RoleRepository
 * @package Model\Repository
 * @table TPP_ROLE
 * @entity RoleEntity	
 * 
 */


class RoleRepository extends ARepository
{
}