<?php //netteCache[01]000379a:2:{s:4:"time";s:21:"0.82910400 1390947774";s:9:"callbacks";a:2:{i:0;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:65:"C:\projects\NetBeans\trans\vendor\Nextras\Datagrid\Datagrid.latte";i:2;i:1381737070;}i:1;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:10:"checkConst";}i:1;s:25:"Nette\Framework::REVISION";i:2;s:22:"released on 2013-12-31";}}}?><?php

// source file: C:\projects\NetBeans\trans\vendor\Nextras\Datagrid\Datagrid.latte

?><?php
// prolog Nette\Latte\Macros\CoreMacros
list($_l, $_g) = Nette\Latte\Macros\CoreMacros::initRuntime($template, 'vi1mi8biup')
;
// prolog Nette\Latte\Macros\UIMacros
//
// block _rows
//
if (!function_exists($_l->blocks['_rows'][] = '_lbe6a512092d__rows')) { function _lbe6a512092d__rows($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v; $_control->redrawControl('rows', FALSE)
;$iterations = 0; foreach ($iterator = $_l->its[] = new Nette\Iterators\CachingIterator($cellsTemplates) as $cellsTemplate) { Nette\Latte\Macros\CoreMacros::includeTemplate($cellsTemplate, get_defined_vars(), $_l->templates['vi1mi8biup'])->render() ;$iterations++; } array_pop($_l->its); $iterator = end($_l->its) ;Nette\Latte\Macros\FormMacros::renderFormBegin($form = $_form = $_control["form"], array('class' => 'ajax')) ?>

<?php $hasActionsColumn = FALSE ;if (isset($_l->blocks["row-actions"])) { $hasActionsColumn = TRUE ;} ?>

<?php if (isset($_l->blocks["global-actions"])) { $hasActionsColumn = TRUE ;} ?>

<?php if (isset($_form['filter'])) { $hasActionsColumn = TRUE ;$hasFilter = TRUE ;} else { $hasFilter = FALSE ;} ?>

<?php if ($control->getEditFormFactory()) { $hasActionsColumn = TRUE ;$hasEdit = TRUE ;} else { $hasEdit = FALSE ;} ?>


<?php if (isset($_l->blocks["table-open-tag"])) { Nette\Latte\Macros\UIMacros::callBlock($_l, 'table-open-tag', $template->getParameters()) ;} else { ?>
<table>
<?php } ?>
<thead>
	<tr class="columns">
<?php $iterations = 0; foreach ($columns as $column) { ?>
		<th class="col-<?php echo htmlSpecialChars($column->name) ?>">
<?php if ($column->canSort()) { ?>
				<a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("sort!", array('orderColumn' => $column->getNewState() ? $column->name : NULL, 'orderType' => $column->getNewState())))) ?>
" class="ajax"><?php echo Nette\Templating\Helpers::escapeHtml($column->label, ENT_NOQUOTES) ?></a>
<?php if ($column->isAsc()) { ?>
					<span class="sort-symbol"><em>&#9650;</em></span>
<?php } elseif ($column->isDesc()) { ?>
					<span class="sort-symbol"><em>&#9660;</em></span>
<?php } } else { ?>
				<?php echo Nette\Templating\Helpers::escapeHtml($column->label, ENT_NOQUOTES) ?>

<?php } ?>
		</th>
<?php $iterations++; } if ($hasActionsColumn) { ?>
		<th class="col-actions"><?php if (isset($_l->blocks["global-actions"])) { Nette\Latte\Macros\UIMacros::callBlock($_l, 'global-actions', $template->getParameters()) ;} ?></th>
<?php } ?>
	</tr>

<?php if ($hasFilter) { ?>
	<tr class="filters">
<?php $_formStack[] = $_form; $formContainer = $_form = $_form["filter"] ;$iterations = 0; foreach ($columns as $column) { ?>
		<th class="col-<?php echo htmlSpecialChars($column->name) ?>">
<?php if (isset($_form[$column->name])) { if (isset($_l->blocks["col-filter-{$column->name}"])) { Nette\Latte\Macros\UIMacros::callBlock($_l, "col-filter-{$column->name}", array('form' => $_form, '_form' => $_form, 'column' => $column) + $template->getParameters()) ;} elseif (isset($_l->blocks["col-filter"])) { Nette\Latte\Macros\UIMacros::callBlock($_l, 'col-filter', array('form' => $_form, '_form' => $_form, 'column' => $column) + $template->getParameters()) ;} else { $_input = is_object($column->name) ? $column->name : $_form[$column->name]; echo $_input->getControl() ;} } ?>
		</th>
<?php $iterations++; } ?>
		<th class="col-actions">
<?php if (isset($_l->blocks["global-filter-actions"])) { Nette\Latte\Macros\UIMacros::callBlock($_l, 'global-filter-actions', array('showCancel' => !empty($control->filter), '_form' => $_form, 'form' => $form) + $template->getParameters()) ;} else { ?>
				<?php echo $_form["filter"]->getControl() ?>

				<?php if (!empty($control->filter)) { echo $_form["cancel"]->getControl() ;} ?>

<?php } ?>
		</th>
<?php $_form = array_pop($_formStack) ?>
	</tr>
<?php } ?>
</thead>
<tbody>
<?php $iterations = 0; foreach ($iterator = $_l->its[] = new Nette\Iterators\CachingIterator($data) as $row) { $primary = $control->getter($row, $rowPrimaryKey) ;$editRow = $editRowKey == $primary ?>
	<tr data-grid-primary="<?php echo htmlSpecialChars($primary) ?>"<?php echo ' id="' . ($_dynSnippetId = $_control->getSnippetId("rows-$primary")) . '"' ?>>
<?php ob_start() ;$iterations = 0; foreach ($iterator = $_l->its[] = new Nette\Iterators\CachingIterator($columns) as $column) { $cell = $control->getter($row, $column->name, FALSE) ;if ($editRow && $column->name != $rowPrimaryKey && isset($_form['edit'][$column->name])) { ?>
				<td class="col-<?php echo htmlSpecialChars($column->name) ?>">
<?php $_formStack[] = $_form; $formContainer = $_form = $_form["edit"] ;$_input = is_object($column->name) ? $column->name : $_form[$column->name]; echo $_input->getControl() ;if ($_form[$column->name]->hasErrors()) { $iterations = 0; foreach ($_form[$column->name]->getErrors() as $error) { ?>
							<p class="error"><?php echo Nette\Templating\Helpers::escapeHtml($error, ENT_NOQUOTES) ?></p>
<?php $iterations++; } } $_form = array_pop($_formStack) ?>
				</td>
<?php } else { if (isset($_l->blocks["col-$column->name"])) { Nette\Latte\Macros\UIMacros::callBlock($_l, "col-{$column->name}", array('row' => $row, 'cell' => $cell, 'iterator' => $iterator) + $template->getParameters()) ;} else { ?>
					<td class="col-<?php echo htmlSpecialChars($column->name) ?>"><?php echo Nette\Templating\Helpers::escapeHtml($control->translate($cell), ENT_NOQUOTES) ?></td>
<?php } } $iterations++; } array_pop($_l->its); $iterator = end($_l->its) ;if ($hasActionsColumn) { ?>
		<td class="col-actions">
<?php if ($editRow) { $_formStack[] = $_form; $formContainer = $_form = $_form["edit"] ;$_input = is_object($rowPrimaryKey) ? $rowPrimaryKey : $_form[$rowPrimaryKey]; echo $_input->getControl() ;if (isset($_l->blocks["row-edit-actions"])) { Nette\Latte\Macros\UIMacros::callBlock($_l, 'row-edit-actions', array('_form' => $_form, 'form' => $form) + $template->getParameters()) ;} else { ?>
						<?php echo $_form["save"]->getControl() ?>

						<?php echo $_form["cancel"]->getControl() ?>

<?php } $_form = array_pop($_formStack) ;} else { if (isset($_l->blocks["row-actions"])) { Nette\Latte\Macros\UIMacros::callBlock($_l, 'row-actions', array('row' => $row, 'primary' => $primary) + $template->getParameters()) ;} elseif ($hasEdit) { ?>
					<a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("edit!", array($primary)))) ?>" class="ajax" data-datagrid-edit>Edit</a>
<?php } } ?>
		</td>
<?php } $_dynSnippets[$_dynSnippetId] = ob_get_flush() ?>	</tr>
<?php $iterations++; } array_pop($_l->its); $iterator = end($_l->its) ;if (isset($echoSnippets)) { unset($_dynSnippets) ;} ?>
</tbody>
<tfoot>
<?php if (isset($paginator)) { ?>
<tr>
	<th colspan="<?php echo htmlSpecialChars(count($columns) + ($hasActionsColumn ? 1 : 0)) ?>">
<?php if (isset($_l->blocks["pagination"])) { Nette\Latte\Macros\UIMacros::callBlock($_l, 'pagination', $template->getParameters()) ;} else { ?>
		<div class="paginator">
<?php if ($paginator->isFirst()) { ?>
				<span class="button">« First</span>
				<span class="button">« Previous</span>
<?php } else { ?>
				<a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("paginate!", array('page' => 1)))) ?>" class="ajax">« First</a>
				<a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("paginate!", array('page' => $paginator->page - 1)))) ?>" class="ajax">« Previous</a>
<?php } ?>

			<span class="counts">
				<span class="current-page"><?php echo Nette\Templating\Helpers::escapeHtml($paginator->page, ENT_NOQUOTES) ?>
</span> / <span class="total-pages"><?php echo Nette\Templating\Helpers::escapeHtml($paginator->pageCount, ENT_NOQUOTES) ?></span>
			</span>

<?php if ($paginator->isLast()) { ?>
				<span class="button">Next »</span>
				<span class="button">Last »</span>
<?php } else { ?>
				<a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("paginate!", array('page' => $paginator->page + 1)))) ?>" class="ajax">Next »</a>
				<a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("paginate!", array('page' => $paginator->pageCount)))) ?>" class="ajax">Last »</a>
<?php } ?>
		</div>
<?php } ?>
	</th>
</tr>
<?php } ?>
</tfoot>
<?php if (isset($_l->blocks["table-close-tag"])) { Nette\Latte\Macros\UIMacros::callBlock($_l, 'table-close-tag', $template->getParameters()) ;} else { ?>
</table>
<?php } Nette\Latte\Macros\FormMacros::renderFormEnd($_form) ;if (isset($_dynSnippets)) return $_dynSnippets; 
}}

//
// end of blocks
//

// template extending and snippets support

$_l->extends = empty($template->_extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $template->_extended = $_extended = TRUE;


if ($_l->extends) {
	ob_start();

} elseif (!empty($_control->snippetMode)) {
	return Nette\Latte\Macros\UIMacros::renderSnippets($_control, $_l, get_defined_vars());
}

//
// main template
//
?>
<div class="datagrid" data-grid-name="<?php echo htmlSpecialChars($control->getUniqueId()) ?>">
<?php if ($_l->extends) { ob_end_clean(); return Nette\Latte\Macros\CoreMacros::includeTemplate($_l->extends, get_defined_vars(), $template)->render(); } ?>
<div id="<?php echo $_control->getSnippetId('rows') ?>"><?php call_user_func(reset($_l->blocks['_rows']), $_l, $template->getParameters()) ?>
</div></div>
