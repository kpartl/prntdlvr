<?php //netteCache[01]000381a:2:{s:4:"time";s:21:"0.62289200 1391116255";s:9:"callbacks";a:2:{i:0;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:67:"C:\projects\NetBeans\trans\app\templates\@bootstrap3.datagrid.latte";i:2;i:1390221052;}i:1;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:10:"checkConst";}i:1;s:25:"Nette\Framework::REVISION";i:2;s:22:"released on 2013-12-31";}}}?><?php

// source file: C:\projects\NetBeans\trans\app\templates\@bootstrap3.datagrid.latte

?><?php
// prolog Nette\Latte\Macros\CoreMacros
list($_l, $_g) = Nette\Latte\Macros\CoreMacros::initRuntime($template, '7grsrfgn4q')
;
// prolog Nette\Latte\Macros\UIMacros
//
// block table-open-tag
//
if (!function_exists($_l->blocks['table-open-tag'][] = '_lbfe130ea033_table_open_tag')) { function _lbfe130ea033_table_open_tag($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>	<table class="table table-bordered table-condensed table-striped">
<?php
}}

//
// block global-filter-actions
//
if (!function_exists($_l->blocks['global-filter-actions'][] = '_lb937b314078_global_filter_actions')) { function _lb937b314078_global_filter_actions($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>	<?php echo $_form["filter"]->getControl()->addAttributes(array('class' => "btn btn-primary btn-small")) ?>

<?php if ($showCancel) { ?>
		<?php echo $_form["cancel"]->getControl()->addAttributes(array('class' => "btn btn-default btn-small")) ?>

<?php } 
}}

//
// block col-filter
//
if (!function_exists($_l->blocks['col-filter'][] = '_lb6727cbc5a0_col_filter')) { function _lb6727cbc5a0_col_filter($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
;$_input = is_object($column->name) ? $column->name : $_form[$column->name]; echo $_input->getControl() ;
}}

//
// block row-edit-actions
//
if (!function_exists($_l->blocks['row-edit-actions'][] = '_lb2e16e671ac_row_edit_actions')) { function _lb2e16e671ac_row_edit_actions($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?>	<?php echo $_form["save"]->getControl()->addAttributes(array('class' => "btn btn-primary btn-small")) ?>

	<?php echo $_form["cancel"]->getControl()->addAttributes(array('class' => "btn btn-default btn-small")) ?>

<?php
}}

//
// block pagination
//
if (!function_exists($_l->blocks['pagination'][] = '_lb7db84afb34_pagination')) { function _lb7db84afb34_pagination($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><ul class="pagination">
<?php if ($paginator->isFirst()) { ?>
	<li class="disabled"><a>« First</a></li>
	<li class="disabled"><a>« Previous</a></li>
<?php } else { ?>
	<li><a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("paginate!", array('page' => 1)))) ?>" class="ajax">« First</a></li>
	<li><a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("paginate!", array('page' => $paginator->page - 1)))) ?>" class="ajax">« Previous</a></li>
<?php } ?>

<li class="active">
	<a><strong><?php echo Nette\Templating\Helpers::escapeHtml($paginator->page, ENT_NOQUOTES) ?>
</strong> / <?php echo Nette\Templating\Helpers::escapeHtml($paginator->pageCount, ENT_NOQUOTES) ?></a>
</li>

<?php if ($paginator->isLast()) { ?>
	<li class="disabled"><a>Next »</a></li>
	<li class="disabled"><a>Last »</a></li>
<?php } else { ?>
	<li><a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("paginate!", array('page' => $paginator->page + 1)))) ?>" class="ajax">Next »</a></li>
	<li><a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("paginate!", array('page' => $paginator->pageCount)))) ?>" class="ajax">Last »</a></li>
<?php } ?>
</ul>
<?php
}}

//
// end of blocks
//

// template extending and snippets support

$_l->extends = empty($template->_extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $template->_extended = $_extended = TRUE;


if ($_l->extends) {
	ob_start();

} elseif (!empty($_control->snippetMode)) {
	return Nette\Latte\Macros\UIMacros::renderSnippets($_control, $_l, get_defined_vars());
}

//
// main template
//
if ($_l->extends) { ob_end_clean(); return Nette\Latte\Macros\CoreMacros::includeTemplate($_l->extends, get_defined_vars(), $template)->render(); } ?>




<?php if ($control->getEditFormFactory()) { $rowActions = 'row-actions' ;} else { $rowActions = 'row-actions-do_not_render' ;} ?>

<?php 

//
// block $rowActions
//
if (!function_exists($_l->blocks[$rowActions]['7grsrfgn4q'] = '_lb1cdf936207__rowActions')) { function _lb1cdf936207__rowActions($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v ?>
	<a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("edit!", array($primary)))) ?>" data-datagrid-edit class="ajax btn btn-small btn-primary">Edit</a>
<?php }} ?>

