<?php

namespace Model;

/**
 * Class CommonFilter
 * @package Model
 */
class Settings {

	
	public static $roles = array(1 => 'admin', 2 => 'operator', 3 => 'viewer');
}

