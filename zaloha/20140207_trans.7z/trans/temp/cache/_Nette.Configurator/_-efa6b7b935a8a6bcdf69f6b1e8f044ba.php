<?php //netteCache[01]010149a:2:{s:4:"time";s:21:"0.39880500 1391761384";s:9:"callbacks";a:61:{i:0;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:49:"C:\projects\NetBeans\trans\app\config\config.neon";i:2;i:1391419864;}i:1;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:55:"C:\projects\NetBeans\trans\app\config\config.local.neon";i:2;i:1390936364;}i:2;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:70:"C:\projects\NetBeans\trans\vendor\Nette\DI\Extensions\PhpExtension.php";i:2;i:1390051398;}i:3;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:76:"C:\projects\NetBeans\trans\vendor\Nette\DI\Extensions\ConstantsExtension.php";i:2;i:1390051398;}i:4;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:72:"C:\projects\NetBeans\trans\vendor\Nette\DI\Extensions\NetteExtension.php";i:2;i:1390051398;}i:5;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:77:"C:\projects\NetBeans\trans\vendor\Nette\DI\Extensions\ExtensionsExtension.php";i:2;i:1390051398;}i:6;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:57:"C:\projects\NetBeans\trans\vendor\Nette\common\Object.php";i:2;i:1390051398;}i:7;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:71:"C:\projects\NetBeans\trans\vendor\Nette\DI\Extensions\NetteAccessor.php";i:2;i:1390051398;}i:8;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:69:"C:\projects\NetBeans\trans\vendor\Nette\Caching\Storages\IJournal.php";i:2;i:1390051398;}i:9;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:72:"C:\projects\NetBeans\trans\vendor\Nette\Caching\Storages\FileJournal.php";i:2;i:1390051398;}i:10;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:60:"C:\projects\NetBeans\trans\vendor\Nette\Caching\IStorage.php";i:2;i:1390051398;}i:11;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:72:"C:\projects\NetBeans\trans\vendor\Nette\Caching\Storages\FileStorage.php";i:2;i:1390051398;}i:12;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:63:"C:\projects\NetBeans\trans\vendor\Nette\Http\RequestFactory.php";i:2;i:1390051398;}i:13;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:57:"C:\projects\NetBeans\trans\vendor\Nette\Http\IRequest.php";i:2;i:1390051398;}i:14;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:56:"C:\projects\NetBeans\trans\vendor\Nette\Http\Request.php";i:2;i:1390051398;}i:15;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:58:"C:\projects\NetBeans\trans\vendor\Nette\Http\IResponse.php";i:2;i:1390051398;}i:16;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:57:"C:\projects\NetBeans\trans\vendor\Nette\Http\Response.php";i:2;i:1390051398;}i:17;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:56:"C:\projects\NetBeans\trans\vendor\Nette\Http\Context.php";i:2;i:1390051398;}i:18;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:56:"C:\projects\NetBeans\trans\vendor\Nette\Http\Session.php";i:2;i:1390051398;}i:19;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:65:"C:\projects\NetBeans\trans\vendor\Nette\Security\IUserStorage.php";i:2;i:1390051398;}i:20;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:60:"C:\projects\NetBeans\trans\vendor\Nette\Http\UserStorage.php";i:2;i:1390051398;}i:21;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:57:"C:\projects\NetBeans\trans\vendor\Nette\Security\User.php";i:2;i:1390051398;}i:22;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:67:"C:\projects\NetBeans\trans\vendor\Nette\Application\Application.php";i:2;i:1390051398;}i:23;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:73:"C:\projects\NetBeans\trans\vendor\Nette\Application\IPresenterFactory.php";i:2;i:1390051398;}i:24;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:72:"C:\projects\NetBeans\trans\vendor\Nette\Application\PresenterFactory.php";i:2;i:1390051398;}i:25;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:63:"C:\projects\NetBeans\trans\vendor\Nette\Application\IRouter.php";i:2;i:1390051398;}i:26;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:56:"C:\projects\NetBeans\trans\vendor\Nette\Mail\IMailer.php";i:2;i:1390051398;}i:27;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:63:"C:\projects\NetBeans\trans\vendor\Nette\Mail\SendmailMailer.php";i:2;i:1390051398;}i:28;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:63:"C:\projects\NetBeans\trans\app\model\Repository\ARepository.php";i:2;i:1391761380;}i:29;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:59:"C:\projects\NetBeans\trans\vendor\LeanMapper\Repository.php";i:2;i:1390514743;}i:30;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:73:"C:\projects\NetBeans\trans\app\model\Repository\DistChannelRepository.php";i:2;i:1390593764;}i:31;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:70:"C:\projects\NetBeans\trans\app\model\Repository\OperatorRepository.php";i:2;i:1390597844;}i:32;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:70:"C:\projects\NetBeans\trans\app\model\Repository\DocumentRepository.php";i:2;i:1390663972;}i:33;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:66:"C:\projects\NetBeans\trans\app\model\Repository\RoleRepository.php";i:2;i:1390593718;}i:34;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:67:"C:\projects\NetBeans\trans\vendor\Nette\Security\IAuthenticator.php";i:2;i:1390051398;}i:35;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:54:"C:\projects\NetBeans\trans\app\model\Authenticator.php";i:2;i:1391086826;}i:36;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:66:"C:\projects\NetBeans\trans\vendor\Nette\Security\IAuthorizator.php";i:2;i:1390051398;}i:37;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:63:"C:\projects\NetBeans\trans\vendor\Nette\Security\Permission.php";i:2;i:1390051398;}i:38;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:69:"C:\projects\NetBeans\trans\app\model\Repository\DocTypeRepository.php";i:2;i:1390169942;}i:39;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:72:"C:\projects\NetBeans\trans\app\model\Repository\StatusTypeRepository.php";i:2;i:1390310418;}i:40;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:56:"C:\projects\NetBeans\trans\vendor\LeanMapper\IMapper.php";i:2;i:1377525066;}i:41;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:61:"C:\projects\NetBeans\trans\app\model\Mapper\DefaultMapper.php";i:2;i:1391344498;}i:42;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:62:"C:\projects\NetBeans\trans\vendor\dibi\libs\DibiConnection.php";i:2;i:1390138707;}i:43;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:58:"C:\projects\NetBeans\trans\vendor\dibi\libs\DibiObject.php";i:2;i:1390393921;}i:44;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:59:"C:\projects\NetBeans\trans\vendor\LeanMapper\Connection.php";i:2;i:1377525066;}i:45;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:69:"C:\projects\NetBeans\trans\app\model\Repository\CompanyRepository.php";i:2;i:1391352592;}i:46;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:66:"C:\projects\NetBeans\trans\app\model\Repository\UserRepository.php";i:2;i:1391209158;}i:47;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:68:"C:\projects\NetBeans\trans\app\model\Repository\StatusRepository.php";i:2;i:1391374186;}i:48;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:73:"C:\projects\NetBeans\trans\app\model\Repository\UserCompanyRepository.php";i:2;i:1391341534;}i:49;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:55:"C:\projects\NetBeans\trans\app\router\RouterFactory.php";i:2;i:1391113280;}i:50;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:56:"C:\projects\NetBeans\trans\vendor\Nette\DI\Container.php";i:2;i:1390051398;}i:51;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:80:"C:\projects\NetBeans\trans\vendor\Nette\Application\Diagnostics\RoutingPanel.php";i:2;i:1390051398;}i:52;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:54:"C:\projects\NetBeans\trans\vendor\Nette\Forms\Form.php";i:2;i:1390051398;}i:53;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:57:"C:\projects\NetBeans\trans\vendor\Nette\Caching\Cache.php";i:2;i:1390051398;}i:54;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:56:"C:\projects\NetBeans\trans\vendor\Nette\Latte\Engine.php";i:2;i:1390051398;}i:55;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:93:"C:\projects\NetBeans\trans\vendor\Nextras\latte-macros\Nextras\Latte\Macros\RedefineMacro.php";i:2;i:1391382092;}i:56;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:56:"C:\projects\NetBeans\trans\vendor\Nette\Mail\Message.php";i:2;i:1390051398;}i:57;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:67:"C:\projects\NetBeans\trans\vendor\Nette\Templating\FileTemplate.php";i:2;i:1390051398;}i:58;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:63:"C:\projects\NetBeans\trans\vendor\Nette\Templating\Template.php";i:2;i:1390051398;}i:59;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:74:"C:\projects\NetBeans\trans\vendor\Nette\Security\Diagnostics\UserPanel.php";i:2;i:1390051398;}i:60;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:73:"C:\projects\NetBeans\trans\vendor\Nette\DI\Diagnostics\ContainerPanel.php";i:2;i:1390051398;}}}?><?php
// source: C:\projects\NetBeans\trans\app/config/config.neon 
// source: C:\projects\NetBeans\trans\app/config/config.local.neon 

/**
 * @property Nette\Application\Application $application
 * @property Model\Authenticator $authenticator
 * @property Nette\Security\Permission $authorizator
 * @property Nette\Caching\Storages\FileStorage $cacheStorage
 * @property Nette\DI\Container $container
 * @property Nette\Http\Request $httpRequest
 * @property Nette\Http\Response $httpResponse
 * @property Nette\DI\Extensions\NetteAccessor $nette
 * @property Nette\Application\IRouter $router
 * @property RouterFactory $routerFactory
 * @property Nette\Http\Session $session
 * @property Nette\Security\User $user
 */
class SystemContainer extends Nette\DI\Container
{

	protected $meta = array(
		'types' => array(
			'nette\\object' => array(
				'nette',
				'nette.cacheJournal',
				'cacheStorage',
				'nette.httpRequestFactory',
				'httpRequest',
				'httpResponse',
				'nette.httpContext',
				'session',
				'nette.userStorage',
				'user',
				'application',
				'nette.presenterFactory',
				'nette.mailer',
				'authenticator',
				'authorizator',
				'container',
			),
			'nette\\di\\extensions\\netteaccessor' => array('nette'),
			'nette\\caching\\storages\\ijournal' => array('nette.cacheJournal'),
			'nette\\caching\\storages\\filejournal' => array('nette.cacheJournal'),
			'nette\\caching\\istorage' => array('cacheStorage'),
			'nette\\caching\\storages\\filestorage' => array('cacheStorage'),
			'nette\\http\\requestfactory' => array('nette.httpRequestFactory'),
			'nette\\http\\irequest' => array('httpRequest'),
			'nette\\http\\request' => array('httpRequest'),
			'nette\\http\\iresponse' => array('httpResponse'),
			'nette\\http\\response' => array('httpResponse'),
			'nette\\http\\context' => array('nette.httpContext'),
			'nette\\http\\session' => array('session'),
			'nette\\security\\iuserstorage' => array('nette.userStorage'),
			'nette\\http\\userstorage' => array('nette.userStorage'),
			'nette\\security\\user' => array('user'),
			'nette\\application\\application' => array('application'),
			'nette\\application\\ipresenterfactory' => array('nette.presenterFactory'),
			'nette\\application\\presenterfactory' => array('nette.presenterFactory'),
			'nette\\application\\irouter' => array('router'),
			'nette\\mail\\imailer' => array('nette.mailer'),
			'nette\\mail\\sendmailmailer' => array('nette.mailer'),
			'model\\repository\\arepository' => array(
				'20_Model_Repository_DistChannelRepository',
				'21_Model_Repository_OperatorRepository',
				'22_Model_Repository_DocumentRepository',
				'23_Model_Repository_RoleRepository',
				'26_Model_Repository_DocTypeRepository',
				'27_Model_Repository_StatusTypeRepository',
				'30_Model_Repository_CompanyRepository',
				'31_Model_Repository_UserRepository',
				'32_Model_Repository_StatusRepository',
				'33_Model_Repository_UserCompanyRepository',
			),
			'leanmapper\\repository' => array(
				'20_Model_Repository_DistChannelRepository',
				'21_Model_Repository_OperatorRepository',
				'22_Model_Repository_DocumentRepository',
				'23_Model_Repository_RoleRepository',
				'26_Model_Repository_DocTypeRepository',
				'27_Model_Repository_StatusTypeRepository',
				'30_Model_Repository_CompanyRepository',
				'31_Model_Repository_UserRepository',
				'32_Model_Repository_StatusRepository',
				'33_Model_Repository_UserCompanyRepository',
			),
			'model\\repository\\distchannelrepository' => array(
				'20_Model_Repository_DistChannelRepository',
			),
			'model\\repository\\operatorrepository' => array(
				'21_Model_Repository_OperatorRepository',
			),
			'model\\repository\\documentrepository' => array(
				'22_Model_Repository_DocumentRepository',
			),
			'model\\repository\\rolerepository' => array('23_Model_Repository_RoleRepository'),
			'nette\\security\\iauthenticator' => array('authenticator'),
			'model\\authenticator' => array('authenticator'),
			'nette\\security\\iauthorizator' => array('authorizator'),
			'nette\\security\\permission' => array('authorizator'),
			'model\\repository\\doctyperepository' => array('26_Model_Repository_DocTypeRepository'),
			'model\\repository\\statustyperepository' => array(
				'27_Model_Repository_StatusTypeRepository',
			),
			'leanmapper\\imapper' => array('28_Model_Mapper_DefaultMapper'),
			'model\\mapper\\defaultmapper' => array('28_Model_Mapper_DefaultMapper'),
			'dibiconnection' => array('29_LeanMapper_Connection'),
			'dibiobject' => array('29_LeanMapper_Connection'),
			'leanmapper\\connection' => array('29_LeanMapper_Connection'),
			'model\\repository\\companyrepository' => array('30_Model_Repository_CompanyRepository'),
			'model\\repository\\userrepository' => array('31_Model_Repository_UserRepository'),
			'model\\repository\\statusrepository' => array('32_Model_Repository_StatusRepository'),
			'model\\repository\\usercompanyrepository' => array(
				'33_Model_Repository_UserCompanyRepository',
			),
			'routerfactory' => array('routerFactory'),
			'nette\\di\\container' => array('container'),
		),
	);


	public function __construct()
	{
		parent::__construct(array(
			'appDir' => 'C:\\projects\\NetBeans\\trans\\app',
			'wwwDir' => 'C:\\projects\\NetBeans\\trans\\www',
			'debugMode' => TRUE,
			'productionMode' => FALSE,
			'environment' => 'development',
			'consoleMode' => FALSE,
			'container' => array(
				'class' => 'SystemContainer',
				'parent' => 'Nette\\DI\\Container',
				'accessors' => TRUE,
			),
			'tempDir' => 'C:\\projects\\NetBeans\\trans\\app/../temp',
			'database' => array(
				'driver' => 'mssql2005',
				'database' => 'trans',
				'host' => 'HP10036276\\SQLEXPRESS',
				'username' => 'trans',
				'password' => 'trans',
				'profiler' => FALSE,
			),
		));
	}


	/**
	 * @return Model\Repository\DistChannelRepository
	 */
	public function createService__20_Model_Repository_DistChannelRepository()
	{
		$service = new Model\Repository\DistChannelRepository($this->getService('29_LeanMapper_Connection'), $this->getService('28_Model_Mapper_DefaultMapper'));
		return $service;
	}


	/**
	 * @return Model\Repository\OperatorRepository
	 */
	public function createService__21_Model_Repository_OperatorRepository()
	{
		$service = new Model\Repository\OperatorRepository($this->getService('29_LeanMapper_Connection'), $this->getService('28_Model_Mapper_DefaultMapper'));
		return $service;
	}


	/**
	 * @return Model\Repository\DocumentRepository
	 */
	public function createService__22_Model_Repository_DocumentRepository()
	{
		$service = new Model\Repository\DocumentRepository($this->getService('29_LeanMapper_Connection'), $this->getService('28_Model_Mapper_DefaultMapper'));
		return $service;
	}


	/**
	 * @return Model\Repository\RoleRepository
	 */
	public function createService__23_Model_Repository_RoleRepository()
	{
		$service = new Model\Repository\RoleRepository($this->getService('29_LeanMapper_Connection'), $this->getService('28_Model_Mapper_DefaultMapper'));
		return $service;
	}


	/**
	 * @return Model\Repository\DocTypeRepository
	 */
	public function createService__26_Model_Repository_DocTypeRepository()
	{
		$service = new Model\Repository\DocTypeRepository($this->getService('29_LeanMapper_Connection'), $this->getService('28_Model_Mapper_DefaultMapper'));
		return $service;
	}


	/**
	 * @return Model\Repository\StatusTypeRepository
	 */
	public function createService__27_Model_Repository_StatusTypeRepository()
	{
		$service = new Model\Repository\StatusTypeRepository($this->getService('29_LeanMapper_Connection'), $this->getService('28_Model_Mapper_DefaultMapper'));
		return $service;
	}


	/**
	 * @return Model\Mapper\DefaultMapper
	 */
	public function createService__28_Model_Mapper_DefaultMapper()
	{
		$service = new Model\Mapper\DefaultMapper;
		return $service;
	}


	/**
	 * @return LeanMapper\Connection
	 */
	public function createService__29_LeanMapper_Connection()
	{
		$service = new LeanMapper\Connection(array(
			'driver' => 'mssql2005',
			'database' => 'trans',
			'host' => 'HP10036276\\SQLEXPRESS',
			'username' => 'trans',
			'password' => 'trans',
			'profiler' => FALSE,
		));
		return $service;
	}


	/**
	 * @return Model\Repository\CompanyRepository
	 */
	public function createService__30_Model_Repository_CompanyRepository()
	{
		$service = new Model\Repository\CompanyRepository($this->getService('29_LeanMapper_Connection'), $this->getService('28_Model_Mapper_DefaultMapper'));
		return $service;
	}


	/**
	 * @return Model\Repository\UserRepository
	 */
	public function createService__31_Model_Repository_UserRepository()
	{
		$service = new Model\Repository\UserRepository($this->getService('29_LeanMapper_Connection'), $this->getService('28_Model_Mapper_DefaultMapper'));
		return $service;
	}


	/**
	 * @return Model\Repository\StatusRepository
	 */
	public function createService__32_Model_Repository_StatusRepository()
	{
		$service = new Model\Repository\StatusRepository($this->getService('29_LeanMapper_Connection'), $this->getService('28_Model_Mapper_DefaultMapper'));
		return $service;
	}


	/**
	 * @return Model\Repository\UserCompanyRepository
	 */
	public function createService__33_Model_Repository_UserCompanyRepository()
	{
		$service = new Model\Repository\UserCompanyRepository($this->getService('29_LeanMapper_Connection'), $this->getService('28_Model_Mapper_DefaultMapper'));
		return $service;
	}


	/**
	 * @return Nette\Application\Application
	 */
	public function createServiceApplication()
	{
		$service = new Nette\Application\Application($this->getService('nette.presenterFactory'), $this->getService('router'), $this->getService('httpRequest'), $this->getService('httpResponse'));
		$service->catchExceptions = FALSE;
		$service->errorPresenter = 'Front:Error';
		Nette\Application\Diagnostics\RoutingPanel::initializePanel($service);
		Nette\Diagnostics\Debugger::getBar()->addPanel(new Nette\Application\Diagnostics\RoutingPanel($this->getService('router'), $this->getService('httpRequest'), $this->getService('nette.presenterFactory')));
		return $service;
	}


	/**
	 * @return Model\Authenticator
	 */
	public function createServiceAuthenticator()
	{
		$service = new Model\Authenticator($this->getService('31_Model_Repository_UserRepository'));
		return $service;
	}


	/**
	 * @return Nette\Security\Permission
	 */
	public function createServiceAuthorizator()
	{
		$service = new Nette\Security\Permission;
		$service->addRole('viewer');
		$service->addRole('operator', 'viewer');
		$service->addRole('admin', 'operator');
		$service->addResource('Front:DocumentDetail');
		$service->addResource('Front:Status');
		$service->allow('operator', 'Front:DocumentDetail', 'edit');
		$service->allow('operator', 'Front:Status', 'edit');
		$service->allow('admin');
		return $service;
	}


	/**
	 * @return Nette\Caching\Storages\FileStorage
	 */
	public function createServiceCacheStorage()
	{
		$service = new Nette\Caching\Storages\FileStorage('C:\\projects\\NetBeans\\trans\\app/../temp/cache', $this->getService('nette.cacheJournal'));
		return $service;
	}


	/**
	 * @return Nette\DI\Container
	 */
	public function createServiceContainer()
	{
		return $this;
	}


	/**
	 * @return Nette\Http\Request
	 */
	public function createServiceHttpRequest()
	{
		$service = $this->getService('nette.httpRequestFactory')->createHttpRequest();
		if (!$service instanceof Nette\Http\Request) {
			throw new Nette\UnexpectedValueException('Unable to create service \'httpRequest\', value returned by factory is not Nette\\Http\\Request type.');
		}
		return $service;
	}


	/**
	 * @return Nette\Http\Response
	 */
	public function createServiceHttpResponse()
	{
		$service = new Nette\Http\Response;
		return $service;
	}


	/**
	 * @return Nette\DI\Extensions\NetteAccessor
	 */
	public function createServiceNette()
	{
		$service = new Nette\DI\Extensions\NetteAccessor($this);
		return $service;
	}


	/**
	 * @return Nette\Forms\Form
	 */
	public function createServiceNette__basicForm()
	{
		$service = new Nette\Forms\Form;
		trigger_error('Service nette.basicForm is deprecated.', 16384);
		return $service;
	}


	/**
	 * @return Nette\Caching\Cache
	 */
	public function createServiceNette__cache($namespace = NULL)
	{
		$service = new Nette\Caching\Cache($this->getService('cacheStorage'), $namespace);
		trigger_error('Service cache is deprecated.', 16384);
		return $service;
	}


	/**
	 * @return Nette\Caching\Storages\FileJournal
	 */
	public function createServiceNette__cacheJournal()
	{
		$service = new Nette\Caching\Storages\FileJournal('C:\\projects\\NetBeans\\trans\\app/../temp');
		return $service;
	}


	/**
	 * @return Nette\Http\Context
	 */
	public function createServiceNette__httpContext()
	{
		$service = new Nette\Http\Context($this->getService('httpRequest'), $this->getService('httpResponse'));
		return $service;
	}


	/**
	 * @return Nette\Http\RequestFactory
	 */
	public function createServiceNette__httpRequestFactory()
	{
		$service = new Nette\Http\RequestFactory;
		$service->setProxy(array());
		return $service;
	}


	/**
	 * @return Nette\Latte\Engine
	 */
	public function createServiceNette__latte()
	{
		$service = new \Nette\Latte\Engine;
		if (!$service instanceof Nette\Latte\Engine) {
			throw new Nette\UnexpectedValueException('Unable to create service \'nette.latte\', value returned by factory is not Nette\\Latte\\Engine type.');
		}
		\Nextras\Latte\Macros\RedefineMacro::install($service->getCompiler());
		return $service;
	}


	/**
	 * @return Nette\Mail\Message
	 */
	public function createServiceNette__mail()
	{
		$service = new Nette\Mail\Message;
		trigger_error('Service nette.mail is deprecated.', 16384);
		$service->setMailer($this->getService('nette.mailer'));
		return $service;
	}


	/**
	 * @return Nette\Mail\SendmailMailer
	 */
	public function createServiceNette__mailer()
	{
		$service = new Nette\Mail\SendmailMailer;
		return $service;
	}


	/**
	 * @return Nette\Application\PresenterFactory
	 */
	public function createServiceNette__presenterFactory()
	{
		$service = new Nette\Application\PresenterFactory('C:\\projects\\NetBeans\\trans\\app', $this);
		$service->setMapping(array('*' => 'App\\*Module\\*Presenter'));
		return $service;
	}


	/**
	 * @return Nette\Templating\FileTemplate
	 */
	public function createServiceNette__template()
	{
		$service = new Nette\Templating\FileTemplate;
		$service->registerFilter($this->getService('nette.latte'));
		$service->registerHelperLoader('Nette\\Templating\\Helpers::loader');
		return $service;
	}


	/**
	 * @return Nette\Caching\Storages\PhpFileStorage
	 */
	public function createServiceNette__templateCacheStorage()
	{
		$service = new Nette\Caching\Storages\PhpFileStorage('C:\\projects\\NetBeans\\trans\\app/../temp/cache', $this->getService('nette.cacheJournal'));
		return $service;
	}


	/**
	 * @return Nette\Http\UserStorage
	 */
	public function createServiceNette__userStorage()
	{
		$service = new Nette\Http\UserStorage($this->getService('session'));
		return $service;
	}


	/**
	 * @return Nette\Application\IRouter
	 */
	public function createServiceRouter()
	{
		$service = $this->getService('routerFactory')->createRouter();
		if (!$service instanceof Nette\Application\IRouter) {
			throw new Nette\UnexpectedValueException('Unable to create service \'router\', value returned by factory is not Nette\\Application\\IRouter type.');
		}
		return $service;
	}


	/**
	 * @return RouterFactory
	 */
	public function createServiceRouterFactory()
	{
		$service = new RouterFactory;
		return $service;
	}


	/**
	 * @return Nette\Http\Session
	 */
	public function createServiceSession()
	{
		$service = new Nette\Http\Session($this->getService('httpRequest'), $this->getService('httpResponse'));
		$service->setExpiration('14 days');
		return $service;
	}


	/**
	 * @return Nette\Security\User
	 */
	public function createServiceUser()
	{
		$service = new Nette\Security\User($this->getService('nette.userStorage'), $this->getService('authenticator'), $this->getService('authorizator'));
		Nette\Diagnostics\Debugger::getBar()->addPanel(new Nette\Security\Diagnostics\UserPanel($service));
		return $service;
	}


	public function initialize()
	{
		date_default_timezone_set('Europe/Prague');
		Nette\Diagnostics\Debugger::getBar()->addPanel(new Nette\DI\Diagnostics\ContainerPanel($this));
		Nette\Caching\Storages\FileStorage::$useDirectories = TRUE;
		$this->getByType("Nette\Http\Session")->exists() && $this->getByType("Nette\Http\Session")->start();
		header('X-Frame-Options: SAMEORIGIN');
		@header('X-Powered-By: Nette Framework');
		@header('Content-Type: text/html; charset=utf-8');
		Nette\Utils\SafeStream::register();
	}

}
