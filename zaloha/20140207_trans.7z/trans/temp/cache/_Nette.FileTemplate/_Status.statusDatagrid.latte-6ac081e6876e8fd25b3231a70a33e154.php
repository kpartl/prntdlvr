<?php //netteCache[01]000394a:2:{s:4:"time";s:21:"0.64484500 1391601658";s:9:"callbacks";a:2:{i:0;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:80:"C:\projects\NetBeans\trans\app\FrontModule\templates\Status\statusDatagrid.latte";i:2;i:1391422185;}i:1;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:10:"checkConst";}i:1;s:25:"Nette\Framework::REVISION";i:2;s:22:"released on 2013-12-31";}}}?><?php

// source file: C:\projects\NetBeans\trans\app\FrontModule\templates\Status\statusDatagrid.latte

?><?php
// prolog Nette\Latte\Macros\CoreMacros
list($_l, $_g) = Nette\Latte\Macros\CoreMacros::initRuntime($template, 'l8stk8yqw8')
;
// prolog Nette\Latte\Macros\UIMacros
//
// block col-id_spool
//
if (!function_exists($_l->blocks['col-id_spool'][] = '_lb43d9554391_col_id_spool')) { function _lb43d9554391_col_id_spool($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><td>
<?php $args = array('id_spool' => $row->id_spool) ?>

	<a href="<?php echo htmlSpecialChars($template->safeurl($_presenter->link("StatusDetail:default", array_merge(array(), $args, array())))) ?>"> 
				<?php echo Nette\Templating\Helpers::escapeHtml($row->id_spool, ENT_NOQUOTES) ?>

	</a>
</td>
<?php
}}

//
// block col-filter-dateIn
//
if (!function_exists($_l->blocks['col-filter-dateIn'][] = '_lb1aba4383a7_col_filter_dateIn')) { function _lb1aba4383a7_col_filter_dateIn($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
;$_formStack[] = $_form; $formContainer = $_form = $_form["dateIn"] ?>
	<?php echo $_form["min"]->getControl() ?>

	<?php echo $_form["max"]->getControl() ?>

<?php $_form = array_pop($_formStack) ;
}}

//
// block col-dateIn
//
if (!function_exists($_l->blocks['col-dateIn'][] = '_lbf7dd1f0812_col_dateIn')) { function _lbf7dd1f0812_col_dateIn($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><td>
	<?php echo Nette\Templating\Helpers::escapeHtml($template->date($row->dateIn, 'd.m.Y H:i:s'), ENT_NOQUOTES) ?>

</td>
<?php
}}

//
// block col-dateProcess
//
if (!function_exists($_l->blocks['col-dateProcess'][] = '_lb4e94b6df12_col_dateProcess')) { function _lb4e94b6df12_col_dateProcess($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><td>
	<?php echo Nette\Templating\Helpers::escapeHtml($template->date($row->dateProcess, 'd.m.Y H:i:s'), ENT_NOQUOTES) ?>

</td>
<?php
}}

//
// block col-datePrint
//
if (!function_exists($_l->blocks['col-datePrint'][] = '_lb171edf0d9e_col_datePrint')) { function _lb171edf0d9e_col_datePrint($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><td>
	<?php echo Nette\Templating\Helpers::escapeHtml($template->date($row->datePrint, 'd.m.Y H:i:s'), ENT_NOQUOTES) ?>

</td>
<?php
}}

//
// block col-dateOut
//
if (!function_exists($_l->blocks['col-dateOut'][] = '_lb302e1dce85_col_dateOut')) { function _lb302e1dce85_col_dateOut($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><td>
	<?php echo Nette\Templating\Helpers::escapeHtml($template->date($row->dateOut, 'd.m.Y H:i:s'), ENT_NOQUOTES) ?>

</td>
<?php
}}

//
// block col-docType
//
if (!function_exists($_l->blocks['col-docType'][] = '_lb4e783b0f88_col_docType')) { function _lb4e783b0f88_col_docType($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><td>
<?php if (isset($row->docType)) { ?>
		<?php echo Nette\Templating\Helpers::escapeHtml($row->docType->name, ENT_NOQUOTES) ?>

<?php } ?>
</td>
<?php
}}

//
// block col-statusType
//
if (!function_exists($_l->blocks['col-statusType'][] = '_lbd22fee5cac_col_statusType')) { function _lbd22fee5cac_col_statusType($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><td>
<?php if (isset($row->statusType)) { ?>
		<?php echo Nette\Templating\Helpers::escapeHtml($row->statusType->name, ENT_NOQUOTES) ?>

<?php } ?>
</td>
<?php
}}

//
// block col-operator
//
if (!function_exists($_l->blocks['col-operator'][] = '_lbe3ac91d1a8_col_operator')) { function _lbe3ac91d1a8_col_operator($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
?><td>
<?php if (isset($row->operator)) { ?>
		<?php echo Nette\Templating\Helpers::escapeHtml($row->operator->name, ENT_NOQUOTES) ?>

<?php } ?>
</td>
<?php
}}

//
// block row-actions
//
if (!function_exists($_l->blocks['row-actions'][] = '_lbe1c264172f_row_actions')) { function _lbe1c264172f_row_actions($_l, $_args) { foreach ($_args as $__k => $__v) $$__k = $__v
;if (($user->isAllowed('Front:Status', 'edit'))) { ?>

	<a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("edit!", array($primary)))) ?>"  class="btn btn-default ajax">Editovat</a>
<?php } 
}}

//
// end of blocks
//

// template extending and snippets support

$_l->extends = empty($template->_extended) && isset($_control) && $_control instanceof Nette\Application\UI\Presenter ? $_control->findLayoutTemplateFile() : NULL; $template->_extended = $_extended = TRUE;


if ($_l->extends) {
	ob_start();

} elseif (!empty($_control->snippetMode)) {
	return Nette\Latte\Macros\UIMacros::renderSnippets($_control, $_l, get_defined_vars());
}

// prolog Nextras\Latte\Macros\RedefineMacro
//
// block table-open-tag
//
$_block = &$_l->blocks['table-open-tag'];$_block = $_block === NULL ? array() : $_block;array_unshift($_block, '_lbf4c3cf91f1_table_open_tag');if (!function_exists('_lbf4c3cf91f1_table_open_tag')) { function _lbf4c3cf91f1_table_open_tag($_l, $_args) { extract($_args)
?>	<table class="table table-bordered table-condensed table-striped">
<?php
}}

//
// block global-filter-actions
//
$_block = &$_l->blocks['global-filter-actions'];$_block = $_block === NULL ? array() : $_block;array_unshift($_block, '_lbd52dee6a78_global_filter_actions');if (!function_exists('_lbd52dee6a78_global_filter_actions')) { function _lbd52dee6a78_global_filter_actions($_l, $_args) { extract($_args)
?>	<?php echo $_form["filter"]->getControl()->addAttributes(array('class' => "btn btn-primary btn-sm")) ?>

<?php if ($showCancel) { ?>
		<?php echo $_form["cancel"]->getControl()->addAttributes(array('class' => "btn btn-default btn-sm")) ?>

<?php } 
}}

//
// block col-filter
//
$_block = &$_l->blocks['col-filter'];$_block = $_block === NULL ? array() : $_block;array_unshift($_block, '_lb47d673a6ea_col_filter');if (!function_exists('_lb47d673a6ea_col_filter')) { function _lb47d673a6ea_col_filter($_l, $_args) { extract($_args)
;$_input = is_object($column->name) ? $column->name : $_form[$column->name]; echo $_input->getControl()->addAttributes(array('class' => "input-sm")) ;
}}

//
// block row-actions-edit
//
$_block = &$_l->blocks['row-actions-edit'];$_block = $_block === NULL ? array() : $_block;array_unshift($_block, '_lbb117502ef1_row_actions_edit');if (!function_exists('_lbb117502ef1_row_actions_edit')) { function _lbb117502ef1_row_actions_edit($_l, $_args) { extract($_args)
?>	<?php echo $_form["save"]->getControl()->addAttributes(array('class' => "btn btn-primary btn-xs")) ?>

	<?php echo $_form["cancel"]->getControl()->addAttributes(array('class' => "btn btn-default btn-xs")) ?>

<?php
}}

//
// block row-actions-edit-link
//
$_block = &$_l->blocks['row-actions-edit-link'];$_block = $_block === NULL ? array() : $_block;array_unshift($_block, '_lb77932afa1d_row_actions_edit_link');if (!function_exists('_lb77932afa1d_row_actions_edit_link')) { function _lb77932afa1d_row_actions_edit_link($_l, $_args) { extract($_args)
?>	<a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("edit!", array($primary)))) ?>
" data-datagrid-edit class="ajax btn btn-primary btn-xs"><?php echo Nette\Templating\Helpers::escapeHtml($control->translate('Edit'), ENT_NOQUOTES) ?></a>
<?php
}}

//
// block pagination
//
$_block = &$_l->blocks['pagination'];$_block = $_block === NULL ? array() : $_block;array_unshift($_block, '_lb761ce37bb4_pagination');if (!function_exists('_lb761ce37bb4_pagination')) { function _lb761ce37bb4_pagination($_l, $_args) { extract($_args)
?><ul class="pagination">
<?php if ($paginator->isFirst()) { ?>
	<li class="disabled"><a>« <?php echo Nette\Templating\Helpers::escapeHtml($control->translate('First'), ENT_NOQUOTES) ?></a></li>
	<li class="disabled"><a>« <?php echo Nette\Templating\Helpers::escapeHtml($control->translate('Previous'), ENT_NOQUOTES) ?></a></li>
<?php } else { ?>
	<li><a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("paginate!", array('page' => 1)))) ?>
" class="ajax">« <?php echo Nette\Templating\Helpers::escapeHtml($control->translate('First'), ENT_NOQUOTES) ?></a></li>
	<li><a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("paginate!", array('page' => $paginator->page - 1)))) ?>
" class="ajax">« <?php echo Nette\Templating\Helpers::escapeHtml($control->translate('Previous'), ENT_NOQUOTES) ?></a></li>
<?php } ?>

<li class="active">
	<a><strong><?php echo Nette\Templating\Helpers::escapeHtml($paginator->page, ENT_NOQUOTES) ?>
</strong> / <?php echo Nette\Templating\Helpers::escapeHtml($paginator->pageCount, ENT_NOQUOTES) ?></a>
</li>

<?php if ($paginator->isLast()) { ?>
	<li class="disabled"><a><?php echo Nette\Templating\Helpers::escapeHtml($control->translate('Next'), ENT_NOQUOTES) ?> »</a></li>
	<li class="disabled"><a><?php echo Nette\Templating\Helpers::escapeHtml($control->translate('Last'), ENT_NOQUOTES) ?> »</a></li>
<?php } else { ?>
	<li><a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("paginate!", array('page' => $paginator->page + 1)))) ?>
" class="ajax"><?php echo Nette\Templating\Helpers::escapeHtml($control->translate('Next'), ENT_NOQUOTES) ?> »</a></li>
	<li><a href="<?php echo htmlSpecialChars($template->safeurl($_control->link("paginate!", array('page' => $paginator->pageCount)))) ?>
" class="ajax"><?php echo Nette\Templating\Helpers::escapeHtml($control->translate('Last'), ENT_NOQUOTES) ?> »</a></li>
<?php } ?>
</ul>
<?php
}}

//
// end of blocks
//

//
// main template
//
if ($_l->extends) { ob_end_clean(); return Nette\Latte\Macros\CoreMacros::includeTemplate($_l->extends, get_defined_vars(), $template)->render(); } ?>










