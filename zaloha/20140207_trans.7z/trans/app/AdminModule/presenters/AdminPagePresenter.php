<?php

namespace App\AdminModule;

use Model;
use Nette;
use Nextras;

/**
 * Class AdminPagePresenter
 * @package App\AdminModule
 */
class AdminPagePresenter extends BasePresenter {
	
	
}
