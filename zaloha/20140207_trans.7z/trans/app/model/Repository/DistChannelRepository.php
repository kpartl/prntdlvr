<?php

namespace Model\Repository;

use Model;

/**
 * Class DistChannelRepository
 * @package Model\Repository
 * @table TPP_DIST_CHANNEL
 * @entity DistChannelEntity	
 * 
 */


class DistChannelRepository extends ARepository
{
}