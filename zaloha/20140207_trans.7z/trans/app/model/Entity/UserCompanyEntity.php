<?php
namespace Model\Entity;
use LeanMapper;

/**
 * @property int $id (ID)
 * @property int $userId (USER_ID)
 * @property int $companyId (COMPANY_ID)
 */
class UserCompany extends AEntity
{
}