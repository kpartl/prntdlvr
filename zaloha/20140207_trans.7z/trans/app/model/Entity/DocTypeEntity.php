<?php
namespace Model\Entity;
use LeanMapper;

/**
 * @property int $id (ID)
 * @property string $name (NAME)
 */
class DocType extends AEntity
{	
}