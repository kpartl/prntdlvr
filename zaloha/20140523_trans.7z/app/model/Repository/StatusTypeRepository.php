<?php
namespace Model\Repository;

use Model;

/**
 * Class StatusTypeRepository
 * @package Model\Repository
 * @table TPP_STATUS_TYPE
 * @entity StatusTypeEntity
 * 
 */

class StatusTypeRepository extends ARepository
{
}