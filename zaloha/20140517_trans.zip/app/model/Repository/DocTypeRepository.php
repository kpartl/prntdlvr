<?php
namespace Model\Repository;

use Model;

/**
 * Class DocTypeRepository
 * @package Model\Repository
 * @table TPP_DOC_TYPE
 * @entity DocTypeEntity
 * 
 */

class DocTypeRepository extends ARepository
{
}