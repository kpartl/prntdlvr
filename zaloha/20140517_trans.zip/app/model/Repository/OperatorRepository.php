<?php
namespace Model\Repository;

use Model;

/**
 * Class OperatorRepository
 * @package Model\Repository
 * @table TPP_OPERATOR
 * @entity OperatorEntity	
 * 
 */

class OperatorRepository extends ARepository
{
}